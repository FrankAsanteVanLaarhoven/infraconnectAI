# InfraConnect Edge SDK
Downloadable package for Edge IoT node authentication and telemetry routing.
1. Connect via Edge Auth Node.
2. Initialize Node or Python client.
3. Call `connect()` and start logging your internal telemetry.
