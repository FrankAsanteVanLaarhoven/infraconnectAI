import requests
class InfraConnectEdge:
    def __init__(self, api_key: str, host: str = "https://infraconnect.ai"):
        self.api_key = api_key
        self.host = host
    def connect(self):
        return True
    def log_metric(self, payload: dict):
        return {"status": "accepted"}
