import { EventEmitter } from 'events';
export class InfraConnectEdge extends EventEmitter {
  constructor(private apiKey: string, private host: string = "wss://infraconnect.ai/ws") { super(); }
  connect() { this.emit('connected'); return true; }
  sendTelemetry(data: any) { this.emit('data', data); }
}
